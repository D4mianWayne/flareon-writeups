bin and include directories of the z3 build should be extracted here
